# Identity-Exposure Audit for Physiological Emotion Recognition

This repository tests whether emotion classifiers actually use exposure to a test participant or a
test stimulus. The main contribution is a paired 2 x 2 training-set intervention that separates:

1. **opportunity**: whether identity-specific label histories could predict emotion;
2. **encoding**: whether identity is decodable from the physiological representation; and
3. **utilization**: whether controlled identity exposure changes emotion predictions.

The method is an evaluation and diagnostic framework, not a new emotion classifier or a claim about
physiological mechanism.

## Dataset Contract

Crossed subject-stimulus analyses require `trial_id` to denote the same physical stimulus for every
participant.

| Dataset | Role |
|---|---|
| DEAP | Crossed analysis using documented video/`Experiment_id` order. First-author evidence and checksum are archived under `docs/evidence/deap/`. |
| MAHNOB-HCI | Crossed analysis using normalized XML `mediaFile` identity. |
| EPPVR | Real two-frontal-channel wearable validation, LOSO, baseline, temporal, calibration, and multimodal analyses only. Record position is not an admissible shared stimulus ID. |

The full evidence boundary is documented in `docs/stimulus_identity_contract.md` and
`docs/deap_ordering_evidence_gap.md`.

## Environment

```powershell
& 'D:\conda_envs\py311\python.exe' -m pip install -r requirements.txt
```

All long-running experiment and bootstrap scripts expose `tqdm` progress bars. The four classical
models use CPU/scikit-learn. PyTorch models use CUDA by default and stop if CUDA is unavailable;
`--allow-cpu` exists only for debugging.

## Canonical Workflow

Build or migrate the row-level caches, then recompute every inferential table:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\migrate_crossed_valid_outputs.py
& 'D:\conda_envs\py311\python.exe' scripts\run_multiseed_protocol_sensitivity.py
& 'D:\conda_envs\py311\python.exe' scripts\run_paired_block_exposure_benchmark.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_paired_block_exposure.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_matched_factorial_effects.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_factorial_robustness.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_factorial_equivalence.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_matched_identity_priors.py
& 'D:\conda_envs\py311\python.exe' scripts\run_threshold_sensitivity.py
```

Identity probes and representation analyses can be trained from scratch with their default commands.
The following commands reproduce current summaries from validated historical row-level OOF
predictions without refitting:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\run_crossed_identity_probes.py --reuse-predictions outputs\crossed_identity_probes\predictions.csv
& 'D:\conda_envs\py311\python.exe' scripts\run_representation_identity_audit.py --reuse-predictions outputs\representation_identity_audit\predictions.csv
& 'D:\conda_envs\py311\python.exe' scripts\run_representation_emotion_gate.py --reuse-predictions outputs\representation_emotion_gate\predictions.csv
& 'D:\conda_envs\py311\python.exe' scripts\run_representation_exposure_gate.py --reuse-predictions outputs\representation_exposure_gate\predictions.csv
& 'D:\conda_envs\py311\python.exe' scripts\run_matched_exposure_benchmark.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_matched_factorial_effects.py --matched-root outputs\matched_identity_exposure_benchmark_crossed_valid
& 'D:\conda_envs\py311\python.exe' scripts\analyze_design_sensitivity.py
```

Cluster-bootstrap random streams are derived from stable SHA-256 labels, so adding or removing a
different dataset does not change the resampling stream assigned to an existing dataset-task result.

## GPU Experiments

The supplementary neural audit requires a CUDA GPU and includes a training progress bar:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\run_gpu_crossed_benchmark.py --axes dual --models mlp conditional_stimulus_adversary --seeds 17 29 43 71 101
```

The script records `device`, GPU name, CUDA-enabled PyTorch version, seeds, and training configuration
in its run manifest. EPPVR must not be added to `dual` or `stimulus` axes; the identity contract rejects
that configuration before training.

## Figures and Final Gate

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\make_identity_audit_figures.py
& 'D:\conda_envs\py311\python.exe' scripts\make_representation_gate_figure.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_canonical_outputs.py
```

Canonical main-analysis roots end in `_crossed_valid`. Historical directories without that suffix
are read-only provenance and may contain exploratory-invalid EPPVR stimulus-axis results. The final
validator checks admitted datasets, table dimensions, paired split contracts, and migration hashes,
then writes `outputs/canonical_validation_report.json`.

## Current Claim Boundary

- DEAP subject-exposure effects are positive for every classifier and split seed in arousal and
  valence. Both survive the contrast-specific Holm plan and the stricter post-hoc 12-test global
  Holm sensitivity analysis.
- DEAP arousal stimulus exposure is equivalent within +/-0.02 BAcc under the primary label rule;
  DEAP valence requires a +/-0.03 margin.
- MAHNOB-HCI arousal stimulus effects are equivalent only within +/-0.03.
- MAHNOB-HCI valence has a positive, midpoint-sensitive stimulus estimate and is equivalent only
  within +/-0.05.
- Subject identity is strongly decodable in both datasets. All subject and stimulus probes exceed
  chance after global Holm correction, but encoding does not establish emotion-model utilization.
- Relative power is the only reduced representation that passes the prespecified post-hoc
  mitigation development gate. This is an empirical candidate, not proof of identity removal or
  universal generalization improvement.

These results do not establish a causal or physiological mechanism, universal absence of stimulus
utilization, or generalization beyond the evaluated datasets and feature contract.

## Q1 Identity-Shortcut Mechanism Workflow

The next-stage study treats the paired exposure design as a measurement instrument and asks when
identity opportunity becomes an exploitable shortcut. Rebuild EPPVR once to add its per-trial
baseline and stimulus-minus-baseline representations:

    & 'D:\conda_envs\py311\python.exe' scripts\build_unified_frontal_features.py --datasets EPPVR

Run the public-dataset counterfactual dose experiment on CUDA, then quantify model-selection
consequences and build the gated material-risk classifier:

    & 'D:\conda_envs\py311\python.exe' scripts\run_counterfactual_identity_dose.py
    & 'D:\conda_envs\py311\python.exe' scripts\analyze_model_ranking_consequences.py
    & 'D:\conda_envs\py311\python.exe' scripts\analyze_identity_shortcut_risk.py

The risk script retains failed continuous-effect regression as a falsification analysis. It creates
`freeze_manifest.json` only when the subject-axis material-risk classifier passes every
leave-dataset-out admission criterion; otherwise only a rejected candidate is written. Only after an
admissible manifest exists, run EPPVR and apply the unchanged classifier:

    & 'D:\conda_envs\py311\python.exe' scripts\run_eppvr_subject_shortcut_validation.py
    & 'D:\conda_envs\py311\python.exe' scripts\apply_frozen_risk_to_eppvr.py
    & 'D:\conda_envs\py311\python.exe' scripts\analyze_external_risk_transport.py
    & 'D:\conda_envs\py311\python.exe' scripts\make_q1_identity_shortcut_figures.py
    & 'D:\conda_envs\py311\python.exe' scripts\validate_identity_shortcut_pipeline.py

EPPVR validates the subject axis only. Its record positions are within-subject repeated units, not
verified cross-participant physical stimulus identities, and the study contains no cross-session
claim because each participant completed one acquisition session.

The locked EPPVR gate must remain unchanged after external outcomes are inspected. The transport
script is a post-external explanatory analysis: it reports configuration-cluster bootstrap intervals
for risk-ranking enrichment, weak calibration, frozen-predictor support violations, and task,
representation, model, and dose sensitivity. It never refits the classifier or changes either frozen
threshold. Current outputs support audit-priority ranking under dataset shift, but not transported
absolute probabilities or a universal fixed operating point.

## Post-External SCMT Experiment

Develop the target-side mechanism transform on public data with CUDA, then apply the frozen
algorithm retrospectively to unlabeled EPPVR mechanism vectors:

    & 'D:\conda_envs\py311\python.exe' scripts\develop_scmt_domain_transport.py
    & 'D:\conda_envs\py311\python.exe' scripts\apply_frozen_scmt_to_eppvr.py
    & 'D:\conda_envs\py311\python.exe' scripts\validate_scmt_transport_pipeline.py

The development script runs 225 GPU fits with progress reporting. The application script fits five
target transforms, then runs 5000 configuration-cluster paired bootstrap repetitions. It reads only
the five EPPVR feature columns until every transformation is fixed and verifies that the original
locked external gate remains byte-identical.

SCMT v2 was revised after the first retrospective EPPVR application by replacing hard displacement
rejection with trust-region residual projection. Therefore, neither SCMT version may be presented as
prospectively or independently validated on EPPVR. The current EPPVR comparison is post-external
method-development evidence; a fourth untouched dataset is required for an independent claim.

## Selective Transport and Abstention Policy

The next revision treats target adaptation as a decision problem rather than assuming one transform
is universally useful. Run the eight-family public synthetic development on CUDA, quantify clustered
uncertainty and decision utility, apply the frozen policy retrospectively to EPPVR, then validate all
artifact and blinding contracts:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\develop_transport_policy.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_transport_policy.py
& 'D:\conda_envs\py311\python.exe' scripts\apply_frozen_transport_policy_to_eppvr.py
& 'D:\conda_envs\py311\python.exe' scripts\make_transport_policy_figure.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_transport_policy_pipeline.py
```

The policy selects among identity, mean shift, CORAL, quantile mapping, support clipping, and SCMT.
Identity is an explicit abstention action. Nested leave-shift-family-out validation evaluates Brier
gain with an AUROC non-inferiority constraint. Label-shift and local-support ambiguity guards encode
conditions under which unsupervised covariate adaptation is not identifiable. EPPVR remains a
retrospective application.

SEED-IV was subsequently registered as an untouched fourth dataset. Reproduce its task features,
counterfactual outcomes, identity probes, one-shot policy application, and integrity validation with
the commands documented in `docs/seediv_external_validation_contract.md`. The frozen policy selected
CORAL, but both the Brier safety and adaptation-benefit gates failed. This negative result is retained
without threshold revision; details are in `docs/seediv_external_validation_results.md`. The current
evidence therefore supports synthetic-shift development and a real-domain falsification result, not
safe cross-dataset transport.

Exact package and GPU versions used for the confirmatory run are recorded in
`requirements-experiment-lock.txt` and `docs/seediv_execution_environment.json`.

## DCS-OPCT v11 Submission Workflow

The frozen v11 method transports configuration-level material identity-optimism probabilities. It
does not calibrate EEG emotion predictions. Reproduce the retrospective matched-budget comparison
against Platt, isotonic, monotone beta, temperature, and split-certified calibrators on CUDA with:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_strong_calibration_baselines.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_crossfit_certified_baselines.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_paired_inference.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_material_threshold_engineering_anchor.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_material_threshold_engineering_anchor.py
```

The calibration runs use nested 20--100% audit budgets, 100 audit orders, 2,000 certificate
bootstrap repetitions, 1,000 GPU optimization epochs, and `tqdm` progress bars. The cross-fit
comparators certify combined out-of-fold predictions over the complete audit budget. Formal paired
inference uses 20,000 bootstrap and 100,000 sign-randomization repetitions plus exact McNemar tests,
with Holm correction across 150 cells. The scripts refuse to run if the frozen v11 manifest hash
changes or if their non-empty output directories already exist. Build and validate the complete
submission artifact package afterward (currently `dcs_opct_v11_submission_artifacts_crossfit_v11`):

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\make_dcs_opct_v11_story_figures.py
& 'D:\conda_envs\py311\python.exe' scripts\make_dcs_opct_v11_submission_artifacts.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_submission_artifacts.py
```

After the artifacts exist, run the complete pre-submission integrity audit with
one command. It refreshes both 13-group prospective pre-access stacks on CUDA,
checks current source hashes, verifies the frozen manifest, and reruns the
independent submission-package validator:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_release_readiness.py
```

Use `--skip-preaccess-refresh` only for a quick local check of already generated
stack reports. The per-dataset access and derivative-release boundaries are in
`docs/dcs_opct_v11_dataset_availability_matrix.md`.

After compiling the manuscript and supplement, create and independently verify
the non-self-referential reproducibility inventory:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\build_dcs_opct_v11_reproducibility_inventory.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_reproducibility_inventory.py
```

The inventory binds the release-readiness evidence, both prospective pre-access
stacks, all artifacts named by the frozen v11 manifest, the validated submission
package, the frozen leave-one-component diagnostic, and the compiled manuscript
files. Its own JSON and validation report are deliberately excluded from the
inventory to prevent circular hashing.

## Reviewer-Closure Sensitivity Analyses

The September 2026 reviewer-closure analyses use the locked Python 3.11
environment, CUDA where model fitting or bootstrap propagation is required, and
progress bars for long-running stages. Run the analyses and independent
validators in this order:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_inductive_target_sensitivity.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_inductive_target_sensitivity.py

& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_raw_group_independence_sensitivity.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_raw_group_independence_sensitivity.py

& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_eppvr_raw_partition_first.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_eppvr_raw_partition_first.py
& 'D:\conda_envs\py311\python.exe' scripts\build_dcs_opct_v11_independence_ladder.py

& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_crossed_cluster_endpoint_uncertainty.py
& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_target_action_endpoint_uncertainty.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_endpoint_uncertainty.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_target_action_endpoint_uncertainty.py

& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_nearest_neighbor_baselines.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_nearest_neighbor_baselines.py

& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_reviewer_closure.py
```

The raw-partition-first EPPVR run rebuilds the complete dose experiment in two
outcome-blind, participant-disjoint 15-person populations. It performs 9,600
emotion-model fits and 160 identity-probe fits, records a 9,760-row provenance
ledger, and uses CUDA for every MLP fit. The frozen applicability gate returns
the original probability in this sensitivity; the result verifies fail-closed
execution under complete training-row separation but is not positive
training-data-independent calibration evidence.

The final validator checks all component reports, both compiled LaTeX logs,
the framework and independence-ladder figures, claim limitations, and
author-only submission items. Passing it establishes closure of the implemented
retrospective analyses, not prospective external effectiveness, a positive
fully training-data-independent release, or universal non-harm.

Run the frozen leave-one-component diagnostic and its independent validator with:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\analyze_dcs_opct_v11_leave_one_component.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_leave_one_component.py
```

This CUDA analysis does not tune any gate. It removes the quantile witness or
the complete unlabeled applicability screen under the same v11 assignment, and
then replaces distribution coverage with the 100 archived random half-audits
while retaining the frozen action and certificate.

## Prospectively Reserved AMIGOS Confirmation

AMIGOS was reserved on 2026-09-09 before participant-level values were accessed.
It is not currently present locally and no positive result is claimed. After the
official EULA-authorized archive is placed at
`E:\AA发表论文的数据\dataset\AMIGOS`, the only authorized first commands are:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\validate_amigos_v11_preaccess.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_amigos_v11_preaccess_stack.py
& 'D:\conda_envs\py311\python.exe' scripts\inspect_amigos_v11_schema.py
```

The second command uses `scipy.io.whosmat` and hashing only. It records variable
names, shapes, MAT types, and stable file bytes without loading participant
arrays. Feature extraction and model fitting remain forbidden until the schema
manifest, analysis scripts, synthetic tests, and implementation lock are all
complete.

After schema inspection, implement the schema-bound files
`scripts/amigos_v11_schema_adapter.py`,
`scripts/test_amigos_v11_schema_adapter.py`, and
`scripts/run_amigos_v11_external_confirmation.py`. Run their synthetic tests
without participant values, then create the one-time implementation lock:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\lock_amigos_v11_external_confirmation.py --confirm-no-participant-values-accessed
```

The attestation flag is valid only if no MAT array, label, signal sample,
derived feature, probability, or outcome has been opened or inspected. The
command refuses missing schema-bound files, failed tests, absent CUDA, changed
frozen artifacts, or an existing output lock.

## Prospectively Reserved Emognition Replication

Emognition is a separately reserved four-channel wearable-EEG replication and
is also unavailable locally. After written EULA authorization and placement of
the official `study_data.zip`, the only authorized first commands are:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\validate_emognition_v11_preaccess.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_emognition_v11_preaccess_stack.py
& 'D:\conda_envs\py311\python.exe' scripts\inspect_emognition_v11_archive_schema.py
```

The inspector reads the ZIP central directory only. After the schema-bound
adapter, synthetic adapter test, and one-shot runner are implemented, lock them
before opening any archive member:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\lock_emognition_v11_external_confirmation.py --confirm-no-participant-values-accessed
```

Neither schema inspection nor implementation locking is an external result.
Every acquisition failure, ineligibility, identity fallback, non-estimable
endpoint, null result, or harmful result remains reportable under the frozen
family registry.

Direct Platt and beta calibration are more effective in four domains at full label budget. Same-audit
cross-fit certification reduces label reuse but still releases harmful corrections in SEED-IV,
DREAMER, and CEAP at the minimum budget. The supported v11 contribution is selective low-label risk
control: identity fallback means non-intervention, observed zero material-negative events are not a
theoretical guarantee, and AVDOS-VR remains post-access exploratory evidence.

The registered FACED 32-channel branch is preserved as a structural eligibility failure because
the two acquisition groups share only 30 physiologically comparable EEG channels. Reproduce the
post-access exploratory common-montage boundary analysis and its publication artifacts with:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\build_faced_v11_post_access_common_montage_features.py
& 'D:\conda_envs\py311\python.exe' scripts\run_faced_v11_post_access_common_montage_dose.py
& 'D:\conda_envs\py311\python.exe' scripts\apply_frozen_dcs_opct_v11_to_faced_post_access_common_montage.py
& 'D:\conda_envs\py311\python.exe' scripts\make_faced_v11_post_access_exploratory_artifacts.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_faced_v11_post_access_common_montage.py
```

The completed FACED analysis contains 123 participants, 2,952 participant--video rows, and 4,500
fits with CUDA MLP training and progress reporting. High identity decodability coexists with zero
material events at the frozen endpoint. Both probability transforms exceed the fixed displacement
budget, so the result supports an exploratory encoding--utilization boundary and identity fallback,
not external calibration effectiveness or universal safety.

## BSPC v19 Submission Package

The September 16, 2026 package refreshes the canonical manuscript, supplement,
cover letter, highlights, author-confirmation checklist, reviewer-closure
reports, the authoritative T1--T11 traceability matrix, EPPVR metadata provenance, and anonymous reproducibility materials. It excludes raw signal files,
participant assignments, row-level population predictions, and fit-provenance
records pending data-governance review.

After compiling the canonical manuscript and supplement, build and validate the
immutable package with:

```powershell
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_reviewer_closure.py
& 'D:\conda_envs\py311\python.exe' scripts\build_dcs_opct_v11_reproducibility_inventory.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_reproducibility_inventory.py
& 'D:\conda_envs\py311\python.exe' scripts\build_dcs_opct_v11_reviewer_task_traceability.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v11_reviewer_task_traceability.py
& 'D:\conda_envs\py311\python.exe' scripts\make_dcs_opct_v19_submission_artifacts.py
& 'D:\conda_envs\py311\python.exe' scripts\validate_dcs_opct_v19_submission_artifacts.py
```

The package validator checks file and source hashes, PDF freshness, LaTeX logs,
the 14/14 reviewer-closure report, the 21/21 raw-partition-first report, the
23/23 reproducibility inventory, the 16/16 T1--T11 traceability report, claim guardrails, sensitive-output exclusion,
and the exact author-dependent blockers. It does not convert unresolved external
data access into scientific evidence.
